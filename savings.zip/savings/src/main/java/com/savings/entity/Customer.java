package com.savings.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "customers")
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String firstName;
    private String lastName;
    private double savingsBalance;

    @ManyToOne
    @JoinColumn(name = "bank_id")
    private Bank bank;

    // Constructors
    public Customer() {}

    public Customer(String firstName, String lastName, double balance, Bank bank) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.savingsBalance = balance;
        this.bank = bank;
    }

    // Business method
    public void calculateMonthlyInterest() {
        double rate = (savingsBalance >= bank.getThresholdAmount())
                ? bank.getPremiumInterestRate()
                : bank.getBaseInterestRate();
        savingsBalance += (savingsBalance * rate) / 12;
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public double getSavingsBalance() {
		return savingsBalance;
	}

	public void setSavingsBalance(double savingsBalance) {
		this.savingsBalance = savingsBalance;
	}

	public Bank getBank() {
		return bank;
	}

	public void setBank(Bank bank) {
		this.bank = bank;
	}
    
    // Getters & Setters (Generate via Eclipse)
}