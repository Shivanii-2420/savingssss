package com.savings.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "banks")
public class Bank {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String name;

    private double baseInterestRate;
    private double premiumInterestRate;
    private double thresholdAmount;

    // Constructors
    public Bank() {}

    public Bank(String name, double baseRate, double premiumRate, double threshold) {
        this.name = name;
        this.baseInterestRate = baseRate;
        this.premiumInterestRate = premiumRate;
        this.thresholdAmount = threshold;
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getBaseInterestRate() {
		return baseInterestRate;
	}

	public void setBaseInterestRate(double baseInterestRate) {
		this.baseInterestRate = baseInterestRate;
	}

	public double getPremiumInterestRate() {
		return premiumInterestRate;
	}

	public void setPremiumInterestRate(double premiumInterestRate) {
		this.premiumInterestRate = premiumInterestRate;
	}

	public double getThresholdAmount() {
		return thresholdAmount;
	}

	public void setThresholdAmount(double thresholdAmount) {
		this.thresholdAmount = thresholdAmount;
	}
    
    // Getters & Setters (Generate via Eclipse: Right-click → Source → Generate Getters/Setters)
}