package com.savings.config;

import com.savings.entity.Bank;
import com.savings.repository.BankRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {
    @Autowired
    private BankRepository bankRepo;

    @Override
    public void run(String... args) throws Exception {
        // Insert banks (like your switch-case)
       
        bankRepo.save(new Bank("Axis Bank", 0.03, 0.035, 500000));
        bankRepo.save(new Bank("HDFC Bank", 0.03, 0.035, 500000));
        bankRepo.save(new Bank("ICICI Bank", 0.03, 0.035, 500000));
        bankRepo.save(new Bank("Central Bank Of India", 0.028, 0.03, 100000000));
        bankRepo.save(new Bank("State Bank Of India", 0.027, 0.03, 100000000));
        bankRepo.save(new Bank("Indian Bank", 0.0275, 0.028, 1000000));
        bankRepo.save(new Bank("Tamilnadu Grameena Bank", 0.0325, 0.0325, 0)); // Fixed interest rate
        bankRepo.save(new Bank("Telengana Grammena Bank", 0.03, 0.03, 0)); // Fixed interest rate

        // Add all other banks...
    }
}