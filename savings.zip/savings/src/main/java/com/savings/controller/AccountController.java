package com.savings.controller;

import com.savings.entity.Bank;
import com.savings.entity.Customer;
import com.savings.repository.BankRepository;
import com.savings.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/accounts")
public class AccountController {

    @Autowired
    private CustomerRepository customerRepo;
    
    @Autowired
    private BankRepository bankRepo;

    // Open a new savings account
    @PostMapping
    public ResponseEntity<?> openAccount(
            @RequestParam String firstName,
            @RequestParam String lastName,
            @RequestParam String bankName,
            @RequestParam double initialDeposit) {
        
        try {
            // Validate input parameters
            if (firstName == null || firstName.trim().isEmpty()) {
                return ResponseEntity.badRequest().body("First name cannot be empty");
            }
            if (lastName == null || lastName.trim().isEmpty()) {
                return ResponseEntity.badRequest().body("Last name cannot be empty");
            }
            if (initialDeposit <= 0) {
                return ResponseEntity.badRequest().body("Initial deposit must be positive");
            }

            // Find bank by name
            Bank bank = bankRepo.findByName(bankName);
            if (bank == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body("Bank not found: " + bankName);
            }

            // Create and save customer
            Customer customer = new Customer(firstName, lastName, initialDeposit, bank);
            Customer savedCustomer = customerRepo.save(customer);
            
            return ResponseEntity.ok(savedCustomer);
            
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error creating account: " + e.getMessage());
        }
    }

    // Get all customers
    @GetMapping
    public ResponseEntity<List<Customer>> getAllCustomers() {
        List<Customer> customers = customerRepo.findAll();
        return ResponseEntity.ok(customers);
    }

    // Calculate interest for all accounts
    @PostMapping("/interest")
    public ResponseEntity<String> calculateInterest() {
        try {
            List<Customer> customers = customerRepo.findAll();
            customers.forEach(customer -> {
                customer.calculateMonthlyInterest();
                customerRepo.save(customer);
            });
            return ResponseEntity.ok("Interest calculated for all accounts");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error calculating interest: " + e.getMessage());
        }
    }
}